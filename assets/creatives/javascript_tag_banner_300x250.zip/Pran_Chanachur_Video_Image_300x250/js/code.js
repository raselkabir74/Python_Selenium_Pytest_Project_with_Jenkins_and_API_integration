
var cur_ev = {
    start: false,
    first: false,
    mid: false,
    third: false,
    wasPlaying: false,
    wasMuted: false,
    wasPaused: false,
    wasResume: false,
    wasComplete: false,
}
let count = 0;

window.addEventListener('load', () => {
    
    gsap.to('#preloader', 0.2, {
        opacity: 0,
        display: 'none',
        onComplete: function () {
            introAnimation();
        }
    });

});

//intro animation
function introAnimation() {
    const playBtn = document.querySelector(".play-pause");
    const muteBtn = document.querySelector(".mute");
    const videoPlayer = document.querySelector(".eskimi-video");
    const adsArea = document.getElementById("adsArea");
    document.getElementById("preloader").style.display = "none";

    let wasUnmute = false;
    let wasMute = false;

    muteBtn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        muteVideo();
    });
    playBtn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        pauseVideo();
    });
    adsArea.addEventListener("click", () => {
        ctaFunction();
    });

    function muteVideo() {
        
        mute = !mute;
        let muteImage = document.getElementById("mute");
        muteImage.src = mute ? "images/mute.png" : "images/unmute.png";

        videoPlayer.muted = mute;

        if(!mute) {
            if (!wasUnmute) {
                wasUnmute = true;
                videoMetrics("unmute");
            }
        } else {
            if (!wasMute) {
                wasMute = true;
                videoMetrics("mute");
            }
        }
    }

    function pauseVideo() {
        play = !play;
        let playImage = document.getElementById("play");
        playImage.src = play ? "images/pause.png" : "images/play.png";
        if (play) {
            videoPlayer.play();
            videoMetrics("resume");
        } else {
            videoPlayer.pause();
            videoMetrics("pause");
        }
    }

    addVideoEvents(videoPlayer);
    videoPlayer.play();
    if (!cur_ev.start) {
        cur_ev.start = true;
        videoMetrics("start");
    }

    bottomAnimation();
}

function bottomAnimation() {
    let btn = gsap.to('.cta', {
        delay: 1,
        scaleX: 0.9,
        repeat: -1,
        yoyo: true,
        // paused: true,
    });

    setInterval(() => {
        count ++;
        gsap.to('.cube', 1, {
            rotateY: -(90 * count),
            ease: Linear.easeNone,
            onComplete: function () {
    
            }
        })
    }, 5000);
}


function addVideoEvents(vid) {
    vid.addEventListener("ended", function (e) {
        if (!cur_ev.wasComplete) {
            cur_ev.wasComplete = true;
            videoMetrics("complete");
        }
        this.play();
    }, false);

    vid.addEventListener("timeupdate", function (e) {
        let duration = this.duration / 4;
        let progress = this.currentTime;

        if (progress > (duration)) {
            if (!cur_ev.first) {
                cur_ev.first = true;
                videoMetrics("firstQuartile");
            }
        }
        if (progress > (duration * 2)) {
            if (!cur_ev.mid) {
                cur_ev.mid = true;
                videoMetrics("midpoint");
            }
        }
        if (progress > (duration * 3)) {
            if (!cur_ev.third) {
                cur_ev.third = true;
                videoMetrics("thirdQuartile");
            }
        }

    }, false);
}